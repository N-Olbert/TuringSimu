#include "../Header/TuringMachine.hpp"
#include "../Header/MachineFactory.hpp"
using namespace ts_business;
TuringMachine MachineFactory::CreateMachineFromFile(std::string& path)
{
	throw std::logic_error("Not implemented");
}
