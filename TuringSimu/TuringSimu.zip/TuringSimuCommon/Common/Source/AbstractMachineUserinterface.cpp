#include "../Header/AbstractMachineUserinterface.hpp"
using namespace ts_common;

void AbstractMachineUserinterface::NotifyInitialized(AbstractMachineUserinterface* toNotify)
{
	if(toNotify != nullptr)toNotify->NotifyInitialized();
}

void AbstractMachineUserinterface::NotifyTapeWritten(AbstractMachineUserinterface* toNotify, char written)
{
	if(toNotify != nullptr)toNotify->NotifyTapeWritten(written);
}

void AbstractMachineUserinterface::NotifyHeadMoved(AbstractMachineUserinterface* toNotify, HeadDirection direction)
{
	if(toNotify != nullptr)toNotify->NotifyHeadMoved(direction);
}

void AbstractMachineUserinterface::NotifyStateChanged(AbstractMachineUserinterface* toNotify, const State& newState)
{
	if(toNotify != nullptr) toNotify->NotifyStateChanged(newState);
}