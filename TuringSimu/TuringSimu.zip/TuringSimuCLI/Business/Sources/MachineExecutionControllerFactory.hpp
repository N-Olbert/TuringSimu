#pragma once
#ifndef TSM_MACHINEEXECUTIONCONTROLLERFACTORY
#define TSM_MACHINEEXECUTIONCONTROLLERFACTORY
#include "../Header/MachineExecutionConsoleController.hpp"
#include "../../../TuringSimuCommon/Common/Header/MachineType.hpp"
#include "../Header/TuringMachineConsoleOutputController.hpp"
#include "../Header/TuringMachineLogfileOutputController.hpp"

enum class UI { Console, LogFile, QtGui };

class MachineExecutionControllerFactory
{
	public:
		static std::unique_ptr<MachineExecutionConsoleController> GetExecutionController(UI ui, MachineType type, const std::string& filePath)
		{
			switch (type) 
			{ 
			case DTM: 
			case NTM: 
			case DEA: 
			case NEA:
				switch (ui)
				{ 
					case UI::Console:
						return std::make_unique<TuringMachineConsoleOutputController>(filePath);
					case UI::LogFile:
						return std::make_unique<TuringMachineLogfileOutputController>(filePath);
						break;
					case UI::QtGui: break;
				}
			default:
				return nullptr;
			}
		}
};
#endif // TSM_MACHINEEXECUTIONCONTROLLERFACTORY
