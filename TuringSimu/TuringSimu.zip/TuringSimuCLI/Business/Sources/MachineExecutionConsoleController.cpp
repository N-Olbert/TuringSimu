#include "../Header/MachineExecutionConsoleController.hpp"
#include "../../../TuringSimu/Business/Header/MachineFactory.hpp"
#include "../../../TuringSimuCommon/UI/Header/UIExecutionDataFactory.hpp"

MachineExecutionConsoleController::MachineExecutionConsoleController(const std::string& machineFilePath)
{
	this->machine = ts_business::MachineFactory::CreateMachineFromFile(machineFilePath, this);
	this->executionData = UIExecutionDataFactory::GetUIExecutionData(this->machine.get());
}

void MachineExecutionConsoleController::NotifyInitialized()
{
	this->executionData->HandleInitialized(this->machine.get());
}

void MachineExecutionConsoleController::NotifyTapeWritten(char written)
{
	this->executionData->HandleTapeWritten(written);
}

void MachineExecutionConsoleController::NotifyHeadMoved(HeadDirection direction)
{
	this->executionData->HandleHeadMoved(direction);
}

void MachineExecutionConsoleController::NotifyStateChanged(const State& newState)
{
	this->executionData->HandleStateChanged(newState);
}

void MachineExecutionConsoleController::ExecuteMachine(bool autoRun)
{
	std::lock_guard<std::mutex> memBarrier{ memoryBarrierForcer };
	PrintMachineExecutionState();
	while (!this->machine->IsFinished())
	{
		BeforeNextExecutionStep(autoRun);
		this->machine->PerformNextStep();
	}

	AfterMachineExecution();
}
