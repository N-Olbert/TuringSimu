#include "../../../TuringSimuCommon/UI/Header/Localization.hpp"
#include "../../../TuringSimuCommon/Common/Header/MachineType.hpp"
#include "../../../TuringSimuCommon/UI/Header/TuringMachineUIExecutionData.hpp"
#include "../Header/TuringMachineLogfileOutputController.hpp"
#include "../../UI/Header/Console.hpp"
#include "../../../TuringSimu/IO/Header/DiskIO.hpp"

TuringMachineLogfileOutputController::TuringMachineLogfileOutputController(const std::string& machineFilePath) : MachineExecutionConsoleController(machineFilePath)
{
	this->logFilePath = "TuringSimuExecutionLog_" + std::to_string(time(NULL)) + ".log";
}


void TuringMachineLogfileOutputController::PrintMachineExecutionState()
{
	if (this->machine != nullptr)
	{
		const auto execData = static_cast<TuringMachineUIExecutionData*>(this->executionData.get());
		stringBuilder.append(Localization::GetString(LocId::CurrentStep));
		stringBuilder.append(std::to_string(static_cast<uint64_t>(execData->GetStepsCounter())));
		stringBuilder.push_back('\n');
		for (size_t i = 0; i < execData->GetPosition(); ++i)
		{
			stringBuilder.push_back(' ');
		}

		stringBuilder.push_back('|');
		stringBuilder.push_back('\n');

		for (char c : execData->GetTape())
		{
			stringBuilder.push_back(c);
		}

		stringBuilder.push_back('\n');
		stringBuilder.append(Localization::GetString(LocId::CurrentState));
		stringBuilder.append(execData->GetCurrentState().ToString());
		stringBuilder.push_back('\n');
		stringBuilder.push_back('\n');
	}
}

void TuringMachineLogfileOutputController::PrintLoadedMachine()
{
	this->OnError("Error: Not implemented function called.");
}

void TuringMachineLogfileOutputController::NotifyStateChanged(const State& newState)
{
	MachineExecutionConsoleController::NotifyStateChanged(newState);
	PrintMachineExecutionState();
}

void TuringMachineLogfileOutputController::OnError(const std::string& errorMessage)
{
	Console::NewLine();
	Console::Print(Localization::GetString(LocId::Error));
	Console::PrintLine(errorMessage);
	stringBuilder.append("\n");
	stringBuilder.append(Localization::GetString(LocId::Error));
	stringBuilder.append(errorMessage);
}

void TuringMachineLogfileOutputController::AfterMachineExecution()
{
	stringBuilder.push_back('\n');
	stringBuilder.push_back('\n');
	auto str = Localization::GetString(LocId::TMTerminatedSuccessfully);
	if (!this->machine->IsFinishedSuccessfully())
	{
		str = Localization::GetString(LocId::TMTerminatedNotSuccessfully);
	}

	stringBuilder.append(str);
	ts_io::WriteToFile(stringBuilder, this->logFilePath);
	Console::PrintDelayed(str);
	Console::PrintLine(Localization::GetString(LocId::EnterToContinue));
	Console::AwaitEnter();
}

void TuringMachineLogfileOutputController::InitAndExecuteMachine()
{
	//Init TM

	Console::ClearScreen();
	Console::Print(Localization::GetString(LocId::RequestTapeInput));
	auto tapeContent = Console::GetStringInput();
	while (!this->machine->InitMachineForExecution(tapeContent))
	{
		Console::Print(Localization::GetString(LocId::TryAgain));
		tapeContent = Console::GetStringInput();
	}

	std::thread{ &MachineExecutionConsoleController::ExecuteMachine, this, true }.join();
}
