#ifndef TM_TURINGMACHINELOGFILEOUTPUTCONTROLLER
#define TM_TURINGMACHINELOGFILEOUTPUTCONTROLLER
#include "MachineExecutionConsoleController.hpp"

class TuringMachineLogfileOutputController : public MachineExecutionConsoleController
{
	private:
		std::string logFilePath;
		std::string stringBuilder;
	public:
		TuringMachineLogfileOutputController(const std::string& machineFilePath);
		void PrintMachineExecutionState() override;
		void PrintLoadedMachine() override;
		void InitAndExecuteMachine() override;
		void NotifyStateChanged(const State& newState) override;
		void OnError(const std::string& errorMessage) override;
		void AfterMachineExecution() override;
};
#endif // TM_TURINGMACHINELOGFILEOUTPUTCONTROLLER