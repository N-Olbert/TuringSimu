#ifndef TMS_COMMANDLINEMACHINEUI
#define TMS_COMMANDLINEMACHINEUI
#include "../../UI/Header/Console.hpp"
#include "../../../TuringSimuCommon/Common/Header/MachineType.hpp"
using namespace ts_common;
using namespace ts_ui;
namespace ts_cliui_business
{
	class BaseConsoleController
	{
		public:
			static void Start();

		private:
			static void PrintMenu();
			static void ChangeLanguage();
			static void ReadInMachine();
			static void PrintLoadedMachineMenu(const std::string& path, MachineType pathType);
	};
}
#endif // TMS_COMMANDLINEMACHINEUI
