#ifndef TM_TURINGMACHINECONSOLEOUTPUTCONTROLLER
#define TM_TURINGMACHINECONSOLEOUTPUTCONTROLLER
#include "MachineExecutionConsoleController.hpp"

class TuringMachineConsoleOutputController : public MachineExecutionConsoleController
{
	public:
		TuringMachineConsoleOutputController(const std::string& machineFilePath) : MachineExecutionConsoleController(machineFilePath) {};
		void PrintMachineExecutionState() override;
		void PrintLoadedMachine() override;
		void InitAndExecuteMachine() override;
		void NotifyStateChanged(const State& newState) override;
		void OnError(const std::string& errorMessage) override;
		void BeforeNextExecutionStep(bool autoRun) override;
	    void AfterMachineExecution() override;
};
#endif // TM_TURINGMACHINECONSOLEOUTPUTCONTROLLER
