#include "../Header/DummyMachineUserInterface.hpp"

void DummyMachineUserInterface::OnError(const std::string& errorMessage)
{
}

void DummyMachineUserInterface::NotifyInitialized()
{
}

void DummyMachineUserInterface::NotifyTapeWritten(char written)
{
}

void DummyMachineUserInterface::NotifyHeadMoved(HeadDirection direction)
{
}

void DummyMachineUserInterface::NotifyStateChanged(const State& newState)
{
	StateChanges++;
}