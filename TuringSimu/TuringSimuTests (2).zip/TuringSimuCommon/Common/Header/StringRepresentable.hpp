#ifndef TM_STRINGREPRESENTABLE
#define TM_STRINGREPRESENTABLE
#include <string>
class StringRepresentable
{
	public:
		virtual ~StringRepresentable() = default;
		virtual std::string ToString() const noexcept = 0;
};
#endif // TM_STRINGREPRESENTABLE
