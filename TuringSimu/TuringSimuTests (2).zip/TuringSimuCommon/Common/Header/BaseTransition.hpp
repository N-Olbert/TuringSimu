#pragma once
#ifndef TMS_BASETRANSITION
#define TMS_BASETRANSITION
namespace ts_common
{
	class BaseTransition
	{
		public:
			virtual ~BaseTransition() = default;
	};
}
#endif // TMS_BASETRANSITION
