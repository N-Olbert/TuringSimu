#pragma once
#ifndef TM_DYNAMICTYPE
#define TM_DYNAMICTYPE
/**
 * \brief Basically a managed void pointer.
 */
class DynamicType
{
	protected:
		virtual void* GetValue() = 0;
	public:
		virtual ~DynamicType() = default;
		template<class T>
		const T& As()
		{
			return *(static_cast<T*>(GetValue()));
		}
};
#endif // TM_DYNAMICTYPE
