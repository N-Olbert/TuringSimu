#ifndef TM_MACHINEEXECUTIONCONSOLECONTROLLER
#define TM_MACHINEEXECUTIONCONSOLECONTROLLER
#include "../../../TuringSimuCommon/Common/Header/AbstractMachine.hpp"
#include "../../../TuringSimuCommon/UI/Header/MachineUIExecutionData.hpp"
#include <mutex>
using namespace ts_ui;
class MachineExecutionController : AbstractMachineUserinterface
{
	private:
		/**
		* \brief Only purpose of this mutex is to force a memory barrier before (and after)
		* we switch to a different thread for machine execution.
		*/
		std::mutex memoryBarrierForcer;
	protected:
		AbstractMachine* machine;
		std::unique_ptr<MachineUIExecutionData> executionData;
	public:
		MachineExecutionController(AbstractMachine* machine);
		virtual ~MachineExecutionController() = default;
		virtual void PrintMachineExecutionState() = 0;
		virtual void PrintLoadedMachine() = 0;
		virtual void InitAndExecuteMachine() = 0;
		void OnInitialized() override;
		void OnTapeWritten(char written) override;
		void OnHeadMoved(HeadDirection direction) override;
		void OnStateChanged(const State& newState) override;
		void ExecuteMachine(bool autoRun);
		virtual void BeforeNextExecutionStep(bool autoRun) {};
		virtual void AfterMachineExecution() {};
};
#endif // TM_MACHINEEXECUTIONCONSOLECONTROLLER
