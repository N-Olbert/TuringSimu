#include "../Header/MachineExecutionController.hpp"
#include "../../../TuringSimu/Business/Header/MachineFactory.hpp"
#include "../../../TuringSimuCommon/UI/Header/UIExecutionDataFactory.hpp"

MachineExecutionController::MachineExecutionController(AbstractMachine* machine)
{
	this->machine = machine;
	this->machine->SetObservingUI(this);
	this->executionData = UIExecutionDataFactory::GetUIExecutionData(this->machine);
}

void MachineExecutionController::OnInitialized()
{
	this->executionData->HandleInitialized(this->machine);
}

void MachineExecutionController::OnTapeWritten(char written)
{
	this->executionData->HandleTapeWritten(written);
}

void MachineExecutionController::OnHeadMoved(HeadDirection direction)
{
	this->executionData->HandleHeadMoved(direction);
}

void MachineExecutionController::OnStateChanged(const State& newState)
{
	this->executionData->HandleStateChanged(newState);
}

void MachineExecutionController::ExecuteMachine(bool autoRun)
{
	std::lock_guard<std::mutex> memBarrier{ memoryBarrierForcer };
	PrintMachineExecutionState();
	while (!this->machine->IsFinished())
	{
		BeforeNextExecutionStep(autoRun);
		this->machine->PerformNextStep();
	}

	AfterMachineExecution();
}
