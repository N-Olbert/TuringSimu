#include "../Header/TuringMachineConsoleOutputController.hpp"
#include "../../UI/Header/Console.hpp"
#include "../../../TuringSimuCommon/UI/Header/Localization.hpp"
#include <cctype>
#include "../../../TuringSimuCommon/Common/Header/HashSet.hpp"
#include "../../../TuringSimuCommon/Common/Header/MachineType.hpp"
#include "../../../TuringSimuCommon/UI/Header/TuringMachineUIExecutionData.hpp"


void TuringMachineConsoleOutputController::PrintMachineExecutionState()
{
	if (this->machine != nullptr)
	{
		const auto execData = static_cast<TuringMachineUIExecutionData*>(this->executionData.get());
		Console::ClearLine();
		for (size_t i = 0; i < execData->GetPosition(); ++i)
		{
			Console::PrintDelayed(' ');
		}

		Console::PrintDelayed('|');
		Console::NewLine();

		Console::ClearLine();
		for (char c : execData->GetTape())
		{
			Console::PrintDelayed(c);
		}

		Console::NewLine();
		Console::ClearLine();
		Console::PrintDelayed(Localization::GetString(LocId::CurrentState));
		Console::PrintDelayed(execData->GetCurrentState().ToString());
		Console::NewLine();
		Console::PrintDelayed(Localization::GetString(LocId::CurrentStep));
		Console::PrintDelayed(static_cast<uint64_t>(execData->GetStepsCounter()));
		Console::LineBack();
		Console::LineBack();
		Console::LineBack();
	}
}

void TuringMachineConsoleOutputController::PrintLoadedMachine()
{
	if (this->machine != nullptr)
	{
		Console::ClearScreen();
		Console::PrintLine("###Loaded machine###");
		auto dyn = this->machine->GetSpecificValue(SpecificMachineValue::Path);
		Console::PrintLine(dyn != nullptr ? dyn->As<std::string>() : Localization::GetString(LocId::Error));
		Console::NewLineDelayed();
		Console::PrintLine("TapeAlphabet");
		dyn = this->machine->GetSpecificValue(SpecificMachineValue::TapeAlphabet);
		Console::PrintEnumerable<HashSet<char>, char>(dyn->As<HashSet<char>>());
		Console::NewLineDelayed();
		Console::PrintLine("Alphabet");
		dyn = this->machine->GetSpecificValue(SpecificMachineValue::Alphabet);
		Console::PrintEnumerable<HashSet<char>, char>(dyn->As<HashSet<char>>());
		Console::NewLineDelayed();
		Console::PrintLine("States");
		dyn = this->machine->GetSpecificValue(SpecificMachineValue::States);
		Console::PrintEnumerable<HashSet<State>>(dyn->As<HashSet<State>>());
		Console::NewLineDelayed();
		Console::PrintLine("Final states");
		dyn = this->machine->GetSpecificValue(SpecificMachineValue::FinalStates);
		Console::PrintEnumerable<HashSet<State>>(dyn->As<HashSet<State>>());
		Console::NewLineDelayed();
		Console::PrintLine("Type");
		dyn = this->machine->GetSpecificValue(SpecificMachineValue::Type);
		Console::PrintLine(TypeToString(dyn->As<MachineType>()));
		Console::NewLineDelayed();
		Console::PrintLine("Blank");
		dyn = this->machine->GetSpecificValue(SpecificMachineValue::Blank);
		Console::PrintLine(dyn->As<char>());
		Console::NewLineDelayed();
		Console::PrintLine("Initial state");
		dyn = this->machine->GetSpecificValue(SpecificMachineValue::InitialState);
		Console::PrintLine(dyn->As<State>());
		Console::NewLineDelayed();
		Console::PrintLine("Transitions");
		dyn = this->machine->GetSpecificValue(SpecificMachineValue::Transitions);
		Console::PrintEnumerable<std::vector<Transition>>(dyn->As<std::vector<Transition>>());
		Console::PrintLine("Press any key to continue...");
		Console::AwaitEnter();
	}
}

void TuringMachineConsoleOutputController::OnStateChanged(const State& newState)
{
	MachineExecutionController::OnStateChanged(newState);
	PrintMachineExecutionState();
}

void TuringMachineConsoleOutputController::OnError(const std::string& errorMessage)
{
	Console::NewLine();
	Console::Print(Localization::GetString(LocId::Error));
	Console::PrintLine(errorMessage);
}

void TuringMachineConsoleOutputController::BeforeNextExecutionStep(bool autoRun)
{
	if (autoRun)
	{
		std::this_thread::sleep_for(std::chrono::seconds(1));
	}
	else
	{
		Console::AwaitEnter();
		Console::LineBack();
	}

	MachineExecutionController::BeforeNextExecutionStep(autoRun);
}

void TuringMachineConsoleOutputController::AfterMachineExecution()
{
	Console::NewLineDelayed();
	Console::NewLineDelayed();
	Console::NewLineDelayed();
	Console::NewLineDelayed();
	Console::NewLineDelayed();
	Console::ShowCursor();

	if (this->machine->IsFinishedSuccessfully())
	{
		Console::PrintDelayed(Localization::GetString(LocId::TMTerminatedSuccessfully));
	}
	else
	{
		Console::PrintDelayed(Localization::GetString(LocId::TMTerminatedNotSuccessfully));
	}

	Console::PrintLine(Localization::GetString(LocId::EnterToContinue));
	Console::AwaitEnter();
}

void TuringMachineConsoleOutputController::InitAndExecuteMachine()
{
	//Init TM
	Console::ClearScreen();
	Console::Print(Localization::GetString(LocId::RequestTapeInput));
	auto tapeContent = Console::GetStringInput();
	while (!this->machine->InitMachineForExecution(tapeContent))
	{
		Console::Print(Localization::GetString(LocId::TryAgain));
		tapeContent = Console::GetStringInput();
	}

	//Select auto run
	Console::ClearScreen();
	Console::HideCursor();
	Console::Print(Localization::GetString(LocId::AutoRunYesNo));
	const auto autoRun = std::tolower(Console::GetCharInput()) != 'y';
	std::thread{ &MachineExecutionController::ExecuteMachine, this, autoRun }.join();
}
