#include "../../../TuringSimuCommon/UI/Header/Localization.hpp"
#include "../../../TuringSimuCommon/Common/Header/MachineType.hpp"
#include "../../../TuringSimuCommon/UI/Header/TuringMachineUIExecutionData.hpp"
#include "../Header/TuringMachineLogfileOutputController.hpp"
#include "../../UI/Header/Console.hpp"
#include "../../../TuringSimu/IO/Header/DiskOutput.hpp"
#include "../../../TuringSimu/IO/Header/DiskIO.hpp"

TuringMachineLogfileOutputController::TuringMachineLogfileOutputController(AbstractMachine* machine) : MachineExecutionController(machine)
{
	this->logFilePath = "TuringSimuExecutionLog_" + std::to_string(time(NULL)) + ".log";
}

void TuringMachineLogfileOutputController::PrintMachineExecutionState()
{
	if (this->machine != nullptr)
	{
		const auto execData = static_cast<TuringMachineUIExecutionData*>(this->executionData.get());
		stringBuilder.append(Localization::GetString(LocId::CurrentStep));
		stringBuilder.append(std::to_string(static_cast<uint64_t>(execData->GetStepsCounter())));
		NewLine();
		for (size_t i = 0; i < execData->GetPosition(); ++i)
		{
			stringBuilder.push_back(' ');
		}

		stringBuilder.push_back('|');
		NewLine();

		for (char c : execData->GetTape())
		{
			stringBuilder.push_back(c);
		}

		NewLine();
		stringBuilder.append(Localization::GetString(LocId::CurrentState));
		stringBuilder.append(execData->GetCurrentState().ToString());
		NewLine();
		NewLine();
	}
}

void TuringMachineLogfileOutputController::PrintLoadedMachine()
{
	this->OnError("Error: Not implemented function called.");
}

void TuringMachineLogfileOutputController::OnStateChanged(const State& newState)
{
	MachineExecutionController::OnStateChanged(newState);
	PrintMachineExecutionState();
}

void TuringMachineLogfileOutputController::OnError(const std::string& errorMessage)
{
	Console::NewLine();
	Console::Print(Localization::GetString(LocId::Error));
	Console::PrintLine(errorMessage);
	stringBuilder.append("\n");
	stringBuilder.append(Localization::GetString(LocId::Error));
	stringBuilder.append(errorMessage);
}

void TuringMachineLogfileOutputController::AfterMachineExecution()
{
	NewLine();
	NewLine();
	auto str = Localization::GetString(LocId::TMTerminatedSuccessfully);
	if (!this->machine->IsFinishedSuccessfully())
	{
		str = Localization::GetString(LocId::TMTerminatedNotSuccessfully);
	}

	stringBuilder.append(str);
	if(ts_io::WriteToFile(this->logFilePath, stringBuilder))
	{
		Console::PrintDelayed(str);
		Console::NewLineDelayed();
		Console::PrintDelayed("Logfile can be found at: ");
		Console::Print(ts_io::GetAbsolutePath(this->logFilePath));
		Console::NewLine();
	}
	else
	{
		Console::PrintLine("Error while creating log file.");
	}

	Console::PrintLine(Localization::GetString(LocId::EnterToContinue));
	Console::AwaitEnter();
}

void TuringMachineLogfileOutputController::InitAndExecuteMachine()
{
	//Init TM

	Console::ClearScreen();
	Console::Print(Localization::GetString(LocId::RequestTapeInput));
	auto tapeContent = Console::GetStringInput();
	while (!this->machine->InitMachineForExecution(tapeContent))
	{
		Console::Print(Localization::GetString(LocId::TryAgain));
		tapeContent = Console::GetStringInput();
	}

	std::thread{ &MachineExecutionController::ExecuteMachine, this, true }.join();
}


void TuringMachineLogfileOutputController::NewLine()
{
	this->stringBuilder.push_back('\n');
}