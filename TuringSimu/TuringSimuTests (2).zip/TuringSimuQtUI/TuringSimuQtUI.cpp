#include "stdafx.h"
#include "TuringSimuQtUI.h"

TuringSimuQtUI::TuringSimuQtUI(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
