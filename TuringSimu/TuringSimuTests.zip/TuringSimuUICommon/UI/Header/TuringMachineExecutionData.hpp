#pragma once
#include <string>
#include <deque>

class TuringMachineExecutionData
{
	std::deque<char> tape;
	size_t position = 0;
	std::string currentState;
	char blank = 0;
};
