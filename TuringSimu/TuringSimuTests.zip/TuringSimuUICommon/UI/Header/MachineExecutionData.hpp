#pragma once
#include <string>
#include "../../../TuringSimu/Common/Header/HeadDirection.hpp"

using nam
class MachineUIExecutionData
{
	public:
		virtual ~MachineUIExecutionData() = default;
		virtual std::string Print() = 0;
		virtual void HandleInitialized() = 0;
		virtual void HandleTapeWritten(char written) = 0;
		virtual void HandleHeadMoved(ts_common::HeadDirection direction) = 0;
		virtual void HandleStateChanged(const std::string& newState) = 0;
};
